// Récupération des éléments du DOM
const openModalBtn = document.getElementById("openModalBtn");
const modal = document.getElementById("modal");
const closeModalBtn = document.getElementById("closeModalBtn");

// Fonction pour ouvrir le modal
openModalBtn.addEventListener("click", () => {
  modal.style.display = "block";
});

// Fonction pour fermer le modal en cliquant sur le bouton de fermeture
closeModalBtn.addEventListener("click", () => {
  modal.style.display = "none";
});

// Fermer le modal en cliquant en dehors de la boîte
window.addEventListener("click", (event) => {
  if (event.target === modal) {
    modal.style.display = "none";
  }
});


const openModalBtn2 = document.getElementById("openModalBtn2");
const modal2 = document.getElementById("modal");
const closeModalBtn2 = document.getElementById("closeModalBtn");

// Fonction pour ouvrir le modal
openModalBtn2.addEventListener("click", () => {
  modal2.style.display = "block";
});

// Fonction pour fermer le modal en cliquant sur le bouton de fermeture
closeModalBtn2.addEventListener("click", () => {
  modal2.style.display = "none";
});

// Fermer le modal en cliquant en dehors de la boîte
window.addEventListener("click", (event) => {
  if (event.target === modal) {
    modal2.style.display = "none";
  }
});




//Afficher le message de succès lors de prise de rendez vous
document.getElementById("appointmentForm").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent form submission
        
        // Show alert
        alert("Votre rendez-vous a été pris avec succès!");

        // Close the modal
        modal.style.display = "none";
		document.getElementById("appointmentForm").reset();

    });




//Fonction Pour la partie simulation 


function calculateFood() {
  const animalType = document.getElementById("animalType").value;
  const weight = parseFloat(document.getElementById("weight").value);
  const activityLevel = document.getElementById("activityLevel").value;
  const result = document.getElementById("result");
  const errorImage = document.getElementById("errorImage"); 
  const foodAmountImage = document.getElementById("foodAmountImage"); 


  errorImage.style.display = "none";
  foodAmountImage.style.display = "none";

  if (!animalType || !weight || !activityLevel) {
      //result.textContent = "Veuillez remplir tous les champs.";
      result.style.color = "red";
      errorImage.style.display = "block";  
      return;
  }

  let multiplier;
  if (animalType === "chien") {
      if (activityLevel === "faible") multiplier = 30;
      else if (activityLevel === "moyen") multiplier = 40;
      else multiplier = 50;
  } else if (animalType === "chat") {
      if (activityLevel === "faible") multiplier = 25;
      else if (activityLevel === "moyen") multiplier = 35;
      else multiplier = 45;
  } else {
      multiplier = 20; 
  }

  const foodAmount = (weight * multiplier).toFixed(2); //Pour afficher deux chiffres après la virgule
  if(foodAmount!=0){
    foodAmountImage.style.display = "block";  
  }
  result.textContent = `Quantité recommandée : ${foodAmount} grammes par jour`;
  result.style.color = "#28a745";
  result.style.fontWeight = "bold";
  result.style.textAlign="center"; 
  result.style.fontSize = "18px";  
}


function resetForm() {
  document.getElementById("foodForm").reset(); // Réinitialise les champs du formulaire
  document.getElementById("result").textContent = ""; // Supprime le résultat affiché
  const errorImage = document.getElementById("errorImage"); 
  const foodAmountImage = document.getElementById("foodAmountImage");
  errorImage.style.display = "none";
  foodAmountImage.style.display = "none";
}